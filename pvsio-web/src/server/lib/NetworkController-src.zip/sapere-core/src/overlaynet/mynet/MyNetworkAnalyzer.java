package overlaynet.mynet;

import eu.sapere.middleware.node.networking.topology.overlay.Neighbour;
import eu.sapere.middleware.node.networking.topology.overlay.NeighbourProperty;
import eu.sapere.middleware.node.networking.topology.overlay.OverlayAnalyzer;
import eu.sapere.middleware.node.networking.topology.overlay.OverlayListener;

/**
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class MyNetworkAnalyzer extends OverlayAnalyzer {

	public MyNetworkAnalyzer(OverlayListener listener, String overlayName) {
		super(listener, overlayName);
		// TODO Auto-generated constructor stub
		//System.out.println("MyStatic Overlay Network initialized");
	}


	@Override
	public void run() {
		
//		Neighbour n1 = new Neighbour("localhost", "alberto", new NeighbourProperty("ciao", "ciao"));
//		addNeighbour(n1);
	}


	@Override
	public void stopOverlay() {
		// TODO Auto-generated method stub
		
	}

}
