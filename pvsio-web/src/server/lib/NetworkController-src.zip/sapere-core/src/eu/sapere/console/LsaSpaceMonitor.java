//package eu.sapere.console;
//
//import eu.sapere_handler.console.implementation.TabbedPaneDemo;
//import eu.sapere_handler.console.implementation.inspector.ContentTracker;
//import eu.sapere_handler.middleware.lsa.Lsa;
//import eu.sapere_handler.middleware.node.lsaspace.console.AbstractLsaSpaceConsole;
//
//import javax.swing.*;
//import java.awt.*;
//
///**
// * Provides a J2SE implementation for the SAPERE Middleware Console
// *
// * @author Marco Santarelli (UNIBO)
// * @author Gabriella Castelli (UNIMORE)
// *
// */
//public class LsaSpaceMonitor extends AbstractLsaSpaceConsole {
//
//	JTextArea lsastext, reactstext;
//
//	private TabbedPaneDemo tabs;
//
//	/** A Content Tracker to track the LSAs in the local space */
//	private ContentTracker cTracker = null;
//
//	/**
//	 * Creates a new SpaceMonitor
//	 *
//	 * @param nodeName
//	 *            The name of the local Node
//	 * @param hasInspector
//	 *            True is the Console should display the Visual Inspector
//	 */
//	public LsaSpaceMonitor(String nodeName, boolean hasInspector) {
//		super(nodeName, hasInspector);
//	}
//
//	public void startConsole() {
//		// this.nodeName = nodeName;
//		cTracker = new ContentTracker();
//		initConsole();
//	}
//
//	private void initConsole() {
//
//		cTracker = new ContentTracker();
//
//		JFrame frame = new JFrame("Node: " + nodeName);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//		tabs = new TabbedPaneDemo(cTracker, inspector);
//
//		// Add content to the window.
//		frame.add(tabs, BorderLayout.CENTER);
//
//		frame.pack();
//		frame.setSize(1200, 600);
//		frame.setResizable(true);
//		frame.setVisible(true);
//	}
//
//	/**
//	 * {@inheritDoc}
//	 */
//	public void publish(final Lsa[] list) {
//
//		tabs.publish(list);
//
//	}
//
//	@Override
//	public boolean hasInspector() {
//		return inspector;
//	}
//
//	@Override
//	public void removeLsa(String lsaId) {
//		if (cTracker != null)
//			cTracker.removeComponent(lsaId);
//	}
//
//	@Override
//	public void removeBond(String from, String to) {
//		if (cTracker != null)
//			cTracker.removeEdge(from, to);
//	}
//
//	@Override
//	public void propagateLsa(String lsaId) {
//		if (cTracker != null)
//			cTracker.propagateComponent(lsaId);
//	}
//
//	@Override
//	public void addBidirectionalBond(String from, String to) {
//		if (cTracker != null)
//			cTracker.addDoubleEdge(from, to);
//
//	}
//
//	@Override
//	public void addUnidirectionalBond(String from, String to) {
//		if (cTracker != null)
//			cTracker.addSingleEdge(from, to);
//
//	}
//
//}
