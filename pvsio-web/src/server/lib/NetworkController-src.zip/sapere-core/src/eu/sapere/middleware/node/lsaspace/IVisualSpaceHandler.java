package eu.sapere.middleware.node.lsaspace;

import java.util.HashMap;

import eu.sapere.middleware.lsa.Lsa;

public interface IVisualSpaceHandler 
{
	public void onSpaceUpdate(final HashMap<String, Lsa> newVisualSpace);
}
