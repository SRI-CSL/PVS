package eu.sapere.middleware.node.notifier.exception;

/**
 * 
 */

/**
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class InvalidEventTypeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1302045576655902539L;
}
