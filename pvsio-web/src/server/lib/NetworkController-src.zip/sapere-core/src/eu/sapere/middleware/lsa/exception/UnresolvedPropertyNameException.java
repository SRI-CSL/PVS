package eu.sapere.middleware.lsa.exception;

/**
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class UnresolvedPropertyNameException extends Exception {

	private static final long serialVersionUID = 4625206717394054090L;

}
