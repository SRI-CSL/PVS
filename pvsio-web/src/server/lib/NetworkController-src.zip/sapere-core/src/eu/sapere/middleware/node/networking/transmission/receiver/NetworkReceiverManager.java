package eu.sapere.middleware.node.networking.transmission.receiver;

import eu.sapere.middleware.agent.BasicSapereAgent;
import eu.sapere.middleware.lsa.Lsa;
import eu.sapere.middleware.node.NodeManager;
import eu.sapere.middleware.node.networking.transmission.protocols.tcpip.LsaReceived;
import eu.sapere.middleware.node.networking.transmission.protocols.tcpip.Server;
import eu.sapere.util.ISystemConfiguration;

/**
 * Provides the tcp-ip implementation for the receiver interface of the Sapere
 * networking.
 * 
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class NetworkReceiverManager implements INetworkReceiverManager,
		LsaReceived {

	private BasicSapereAgent agent = null;

	/**
	 * Instantiates the NetworkReceiverManager.
	 */
	public NetworkReceiverManager() {

		new Server(
				new Integer(NodeManager.getSystemConfiguration()
						.getProperties()
						.getProperty(ISystemConfiguration.NETWORK_PORT)), this);
	}

	public void doInject(Lsa receivedLsa) {

		agent = new BasicSapereAgent("networkReceiverManager");

		agent.injectOperation(receivedLsa);

	}

	public void onLsaReceived(Lsa lsaReceived) {

		doInject(lsaReceived);

	}

}
