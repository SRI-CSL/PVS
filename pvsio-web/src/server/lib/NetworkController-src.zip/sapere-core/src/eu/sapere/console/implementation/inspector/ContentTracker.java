/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.sapere.console.implementation.inspector;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * 
 * @author root
 */
public class ContentTracker {

	private Hashtable<String, JitterNode> jitterHash = new Hashtable<String, JitterNode>();
	private Hashtable<String, VisualLSA> compHash = new Hashtable<String, VisualLSA>();
	private Vector<JitterNode> displayNodes = new Vector<JitterNode>();
	//private Vector<JitterNode> decayedNodes = new Vector<JitterNode>();
	private Vector<Edge> doubleEdges = new Vector<Edge>();
	private Vector<Edge> singleEdges = new Vector<Edge>();

	private LSAList list = null;

	/**
   * 
   */
	public ContentTracker() {
		list = new LSAList();
	}

	/**
   * 
   */
	public synchronized void removeAll() {
		synchronized (doubleEdges) {
			doubleEdges.clear();
		}
		synchronized (singleEdges) {
			singleEdges.clear();
		}
		synchronized (displayNodes) {
			displayNodes.clear();
		}

		jitterHash.clear();
		compHash.clear();

		if (list != null)
			list.removeAll();
	}

	public LSAList getList() {
		return list;
	}


	public List<JitterNode> getNodes() {
		return displayNodes;
	}


	public List<Edge> getDoubleEdges() {
		return doubleEdges;
	}

	public List<Edge> getSingleEdges() {
		return singleEdges;
	}

	public Enumeration<VisualLSA> getCompHash() {
		return compHash.elements();
	}

	public synchronized void addComponent(VisualLSA kComp) {

		if (kComp == null) {
			return;
		}

		if (compHash.containsKey(kComp.getLsaId().toLowerCase())) {
			VisualLSA old = compHash.get(kComp.getLsaId().toLowerCase());
			old.setContent(kComp.getContent());
		}

		if (!compHash.containsKey(kComp.getLsaId().toLowerCase())) {
			compHash.put(kComp.getLsaId().toLowerCase(), kComp);

			if (list != null)
				list.addLSA(kComp.getLsaId(), kComp.getStatus());

			LsaNode cNode = new LsaNode(kComp);
			displayNodes.add(cNode);
			jitterHash.put(kComp.getLsaId().toLowerCase(), cNode);

		}

	}

	public void decayComponent(String uuid) {

		if (uuid == null) {
			return;
		}

		for (JitterNode n : displayNodes) {
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(uuid)) {
				System.out.println(uuid);
				((LsaNode) n).decayed = true;
			}
		}

		Vector<Edge> toBeRemovedDouble = new Vector<Edge>();
		Vector<Edge> toBeRemovedSingle = new Vector<Edge>();

		for (Edge e : doubleEdges)
			if (e.hasEdge(uuid))
				toBeRemovedDouble.add(e);

		for (Edge e : singleEdges)
			if (e.hasEdge(uuid))
				toBeRemovedSingle.add(e);

		// Remove Edges
		for (Edge e : toBeRemovedDouble)
			doubleEdges.remove(e);

		for (Edge e : toBeRemovedSingle)
			singleEdges.remove(e);
	}

	public void propagateComponent(String uuid) {

		// System.out.println("MARK AS PROPAGATED ? "+uuid);

		if (uuid == null) {
			return;
		}

		for (JitterNode n : displayNodes) {
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(uuid)) {
				// System.out.println("MARK AS PROPAGATED "+uuid);
				((LsaNode) n).propagated = true;
			}
		}

	}

	public void removeComponent(String uuid) {
		if (uuid == null) {
			return;
		}

		Vector<Edge> toBeRemovedDouble = new Vector<Edge>();
		Vector<Edge> toBeRemovedSingle = new Vector<Edge>();

		for (Edge e : doubleEdges)
			if (e.hasEdge(uuid))
				toBeRemovedDouble.add(e);

		for (Edge e : singleEdges)
			if (e.hasEdge(uuid))
				toBeRemovedSingle.add(e);

		// Remove Edges
		for (Edge e : toBeRemovedDouble)
			doubleEdges.remove(e);

		for (Edge e : toBeRemovedSingle)
			singleEdges.remove(e);

		removeComponentEdges(uuid);
	}

	/**
	 * 
	 * @param uuid
	 */
	public void removeComponentEdges(String uuid) {

		if (uuid == null) {
			return;
		}

		if (list != null)
			list.removeLSA(uuid);

		compHash.remove(uuid.toLowerCase());

		removefromJitter(uuid);

	}

	private void removefromJitter(String uuid) {

		synchronized (doubleEdges) {
			for (Iterator<Edge> it = doubleEdges.iterator(); it.hasNext();) {
				Edge nextEdge = it.next();
				VisualLSA kncTo = (VisualLSA) nextEdge.to.getUserObject();
				VisualLSA kncFrom = (VisualLSA) nextEdge.from.getUserObject();
				if (kncTo.isToBeRemoved()) {
					displayNodes.remove(nextEdge.to);
					it.remove();
					continue;
				}
				if (kncFrom.isToBeRemoved()) {
					if (kncTo.isAtom()) {
						displayNodes.remove(nextEdge.to);
					}
					it.remove();
				}
			}
		}

		synchronized (singleEdges) {
			for (Iterator<Edge> it = singleEdges.iterator(); it.hasNext();) {
				Edge nextEdge = it.next();
				VisualLSA kncTo = (VisualLSA) nextEdge.to.getUserObject();
				VisualLSA kncFrom = (VisualLSA) nextEdge.from.getUserObject();
				if (kncTo.isToBeRemoved()) {
					displayNodes.remove(nextEdge.to);
					it.remove();
					continue;
				}
				if (kncFrom.isToBeRemoved()) {
					if (kncTo.isAtom()) {
						displayNodes.remove(nextEdge.to);
					}
					it.remove();
				}
			}
		}

		JitterNode jNode = jitterHash.remove(uuid.toLowerCase());
		if (jNode != null) {
			synchronized (displayNodes) {
				displayNodes.remove(jNode);
			}
		}
	}


	private synchronized void addEdge(JitterNode fromNode, JitterNode toNode,
			boolean doubleEdge) {
		if ((fromNode != null) && (toNode != null)) {
			Edge e = new Edge(fromNode, toNode);

			if (doubleEdge) {
				List<Edge> edgeList = getDoubleEdges();
				synchronized (edgeList) {
					edgeList.add(e);
				}
			} else {
				List<Edge> edgeList = getSingleEdges();
				synchronized (edgeList) {
					edgeList.add(e);
				}
			}
		}
	}

	public void addDoubleEdge(String from, String to) {

		VisualLSA fromVisualLSA = null;
		VisualLSA toVisualLSA = null;

		for (JitterNode n : displayNodes) {
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(from))
				fromVisualLSA = (VisualLSA) n.getUserObject();
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(to))
				toVisualLSA = (VisualLSA) n.getUserObject();
		}

		if (fromVisualLSA != null && toVisualLSA != null)
			addDoubleEdge(fromVisualLSA, toVisualLSA);

	}

	private void addDoubleEdge(VisualLSA from, VisualLSA to) {

		JitterNode fromNode = jitterHash.get(from.getLsaId().toLowerCase());
		JitterNode toNode = jitterHash.get(to.getLsaId().toLowerCase());

		addEdge(fromNode, toNode, true);
	}

	public void addSingleEdge(String from, String to) {

		VisualLSA fromVisualLSA = null;
		VisualLSA toVisualLSA = null;

		for (JitterNode n : displayNodes) {
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(from))
				fromVisualLSA = (VisualLSA) n.getUserObject();
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(to))
				toVisualLSA = (VisualLSA) n.getUserObject();
		}

		if (fromVisualLSA != null && toVisualLSA != null)
			addSingleEdge(fromVisualLSA, toVisualLSA);

	}

	private void addSingleEdge(VisualLSA from, VisualLSA to) {
		JitterNode fromNode = jitterHash.get(from.getLsaId().toLowerCase());
		JitterNode toNode = jitterHash.get(to.getLsaId().toLowerCase());

		addEdge(fromNode, toNode, false);
	}

	public void removeEdge(String from, String to) {

		// System.out.println("trying to remove edges from"+from+" to "+to);

		VisualLSA fromVisualLSA = null;
		VisualLSA toVisualLSA = null;

		for (JitterNode n : displayNodes) {
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(from))
				fromVisualLSA = (VisualLSA) n.getUserObject();
			if (((VisualLSA) n.getUserObject()).getLsaId().equals(to))
				toVisualLSA = (VisualLSA) n.getUserObject();
		}

		if (fromVisualLSA == null || toVisualLSA == null)
			return;

		JitterNode fromNode = jitterHash.get(fromVisualLSA.getLsaId()
				.toLowerCase());
		JitterNode toNode = jitterHash
				.get(toVisualLSA.getLsaId().toLowerCase());

		if ((fromNode != null) && (toNode != null)) {
			//Edge e = new Edge(fromNode, toNode);

			List<Edge> edgeList = getDoubleEdges();

			synchronized (edgeList) {
				for (Edge ee : edgeList) {

					if ((((VisualLSA) ee.from.getUserObject()).getLsaId()
							.equals(fromVisualLSA.getLsaId()) && ((VisualLSA) ee.to
							.getUserObject()).getLsaId().equals(
							toVisualLSA.getLsaId()))
							|| (((VisualLSA) ee.from.getUserObject())
									.getLsaId().equals(toVisualLSA.getLsaId()) && ((VisualLSA) ee.to
									.getUserObject()).getLsaId().equals(
									fromVisualLSA.getLsaId()))) {
						synchronized (edgeList) {
							if (edgeList.size() == 1) {

//								boolean b = edgeList.remove(ee);
//								System.out.println("double removed "+b);
								return;
							}
//							boolean b = edgeList.remove(ee);
//							System.out.println("double removed "+b);

						}
					}
				}
			}

			List<Edge> edgeList2 = getSingleEdges();
			// System.out.println(edgeList2.size());
			synchronized (edgeList2) {
				for (Edge ee2 : edgeList2) {

					// System.out.print
					// ("from: "+((VisualLSA)ee2.from.getUserObject()).getLsaId());
					// System.out.println("to: "+((VisualLSA)ee2.to.getUserObject()).getLsaId());

					if (((VisualLSA) ee2.from.getUserObject()).getLsaId()
							.equals(from)
							&& ((VisualLSA) ee2.to.getUserObject()).getLsaId()
									.equals(to)) {
						synchronized (edgeList2) {
							if (edgeList2.size() == 1) {

//								boolean b = edgeList2.remove(ee2);
//								System.out.println("single removed "+b);
								return;
							}
//							boolean b = edgeList2.remove(ee2);
//							System.out.println("single removed "+b);
						}
					}
				}
			}

		}
	}
}
