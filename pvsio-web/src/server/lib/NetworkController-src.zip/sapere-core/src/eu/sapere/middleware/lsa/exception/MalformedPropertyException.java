package eu.sapere.middleware.lsa.exception;

/**
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class MalformedPropertyException extends RuntimeException {

	private static final long serialVersionUID = -5178846725712072559L;
}
