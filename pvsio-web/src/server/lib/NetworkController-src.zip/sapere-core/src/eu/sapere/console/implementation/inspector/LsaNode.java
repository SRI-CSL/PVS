/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package eu.sapere.console.implementation.inspector;

import java.awt.Color;
import java.util.Random;

/**
 * 
 * @author root
 */
public class LsaNode extends JitterNode {

	static Random rng = new Random();

	private String annotation = new String();

	private int width = 50; // max lenght of String, used to improve
							// visualization

	public boolean decayed = false;
	public boolean aggregated = false;
	public boolean propagated = false;
	public boolean activelyPropagated = false;

	public int ttl = 200;

	/**
	 * 
	 * @param knComp
	 */
	public LsaNode(VisualLSA knComp) {
		super(knComp);
		setColor();
		setDefaultAnnotation();
	}

	private void setColor() {
		int n = rng.nextInt(SapereColors.fillings.length);
		color = SapereColors.fillings[n];
		borderColor = SapereColors.borders[n];
	}

	@SuppressWarnings("unused")
	private void setColor(Color filling, Color border) {
		color = filling;
		borderColor = border;
	}

	@Override
	public String getLabel() {
		return ((VisualLSA) getUserObject()).getContent();
	}

	private void setDefaultAnnotation() {
		this.annotation = new String();
		int addChars = width - annotation.length();
		while (addChars > 0) {
			annotation.concat(" ");
			--addChars;
		}

	}

	public void setAnnotation(String annotation) {
		this.annotation = annotation;
	}

	public String getAnnotation(String annotation) {
		return annotation;
	}
}
