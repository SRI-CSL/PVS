package eu.sapere.middleware.node.lsaspace.ecolaws;

import eu.sapere.middleware.lsa.Lsa;
import eu.sapere.middleware.lsa.Property;
import eu.sapere.middleware.lsa.values.PropertyName;
import eu.sapere.middleware.node.INodeManager;
import eu.sapere.middleware.node.notifier.event.AbstractSapereEvent;
import eu.sapere.middleware.node.notifier.event.DecayedEvent;
import eu.sapere.middleware.node.notifier.event.LsaUpdatedEvent;

/**
 * The Decay eco-law implementation.
 * 
 * @author Gabriella Castelli (UNIMORE)
 * @author Graeme Stevenson (STA)
 */
public class Decay extends AbstractEcoLaw {

	/**
	 * Creates a new instance of the decay eco-law.
	 * 
	 * @param nodeManager
	 *            The nodeManager of the space.
	 */
	public Decay(INodeManager nodeManager) {
		super(nodeManager);
	}

	/**
	 * {@inheritDoc}
	 */
	public void invoke() {
		for (Lsa lsa : getLSAs()) {
			if (lsa.getSingleValue("decay") != null) {
				applyToLsa(lsa);
			}
		}
	}

	/**
	 * Applies the decay transformation to an LSA.
	 * 
	 * @param an_lsa
	 *            the LSA to decay.
	 */
	private void applyToLsa(final Lsa an_lsa) {
		// decrement the TTL
		int decay = PropertyName.decrement(an_lsa.getDecayProperty());

		if (decay <= 0) {

			// Triggers the DecayedEvent
			AbstractSapereEvent decayEvent = new DecayedEvent(an_lsa);
			decayEvent.setRequiringAgent(null);
			publish(decayEvent);

			remove(an_lsa);

			// Should remove all the Subscriptions for this LSA
		} else {
			an_lsa.addProperty(new Property("decay", String.valueOf(decay)));
			update(an_lsa);

			// Triggers the LsaUpdatedEvent
			AbstractSapereEvent lsaUpdatedEvent = new LsaUpdatedEvent(an_lsa);
			lsaUpdatedEvent.setRequiringAgent(null);
			publish(lsaUpdatedEvent);
		}
	}

}
