package eu.sapere.middleware.node.lsaspace;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import eu.sapere.middleware.lsa.Lsa;

public class SpaceView {

	private HashMap<String, Lsa> visualSpace = null;
	private static IVisualSpaceHandler handler=null;
	
	public SpaceView()
	{
		visualSpace = new HashMap<String, Lsa>();
	}
	
	public void updateVisualSpace(final HashMap<String, Lsa> currentSpace)
	{
		// true if we must publish the visual space
		boolean changed = false;
		
		Set<String> currentKeys = currentSpace.keySet();
		Set<String> visualKeys = visualSpace.keySet();
		
		ArrayList<String> visualToRemove = new ArrayList<String>();
		
		// check the current space content against the visual one
		// looking for new or updated LSAs
		//

		// look for removed LSAs
		for (String lsaId : visualKeys)
		{
			if (currentKeys.contains(lsaId))
			{
				// this LSAs is contained in the current space.
				// check if it is changed
				String currentContent = currentSpace.get(lsaId).toString();
				
				String visualContent = visualSpace.get(lsaId).toString();
				
				if (visualContent.compareTo(currentContent) != 0)
				{
					changed = true;
					// replace the old value
					visualSpace.put(lsaId, currentSpace.get(lsaId));
				}	
			}
			else
			{
				// this LSAs is not in the space anymore,
				// delete it
				changed = true;
				visualToRemove.add(lsaId);
			}
		}
		
		// look for new LSAs
		for (String lsaId : currentKeys)
		{
			if (visualKeys.contains(lsaId) == false)
			{
				changed = true;
				// this LSA is not contained in the visual space.
				// add it
				visualSpace.put(lsaId, currentSpace.get(lsaId));
			}
		}
		
		// remove old LSAs
		//
		for (int i = 0; i < visualToRemove.size(); i++)
			visualSpace.remove(visualToRemove.get(i));
		
		if (changed == true && handler != null)
			handler.onSpaceUpdate(visualSpace);
	}
	
	public static void setSpaceUpdateHandler(IVisualSpaceHandler view)
	{
		if (handler == null)
			handler = view;
	}
	
}
