/**
 * @module JsonHelper
 * @version 1.0
 * @description
 * Helper Class to generate proper JSONObject
 * These are usually messages for Monitor sessions, used to keep it updated of the Network Controller internal status
 * @author Piergiuseppe Mallozzi
 * @date 19/05/15 16:47:00 AM
 */

package network_controller.json;

import network_controller.model.Device;
import network_controller.sapere.PublishAgent;
import network_controller.sapere.SubscribeAgent;

import javax.json.JsonObject;
import javax.json.spi.JsonProvider;


public class JsonHelper {

    /**
     * Generates a message that signals the addition of a Device to the Network Controller Space.
     * (Destined to a Monitor)
     * @param device Device element
     * @return JsonObject
     */
    public static JsonObject add(Device device) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "add")
                .add("deviceID", device.getDeviceID())
                .add("type", device.getType())
                .add("status", device.getStatus())
                .add("description", device.getDescription())
                .build();
    }

    /**
     * Generates a message that signals the removal of a Device from the Network Controller Space.
     * (Destined to a Monitor)
     * @param device Device element
     * @return JsonObject
     */
    public static JsonObject remove(Device device) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "remove")
                .add("deviceID", device.getDeviceID())
                .build();
    }

    /**
     * Generates a message that signals that the Device changed it's internal state.
     * (Destined to a Monitor)
     * Hence has been activated or de-activated.
     * @param device Device element
     * @return JsonObject
     */
    public static JsonObject toggle(Device device) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "toggle")
                .add("deviceID", device.getDeviceID())
                .add("type", device.getType())
                .add("status", device.getStatus())
                .build();
    }

    /**
     * Generates a message that signals that the Device changed it's internal state.
     * (Destined to a Monitor)
     * Hence has been activated or de-activated.
     * @param device_ID element
     * @return JsonObject
     */
    public static JsonObject connected(String device_ID) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "connected")
                .add("deviceID", device_ID)
                .build();
    }

    /**
     * Generates a message that signals that the Device changed it's internal state.
     * (Destined to a Monitor)
     * Hence has been activated or de-activated.
     *
     * @param device_ID
     * @return JsonObject
     */
    public static JsonObject disconnected(String device_ID) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "disconnected")
                .add("deviceID", device_ID)
                .build();
    }

    /**
     * Generates an update message.
     * (Destined to a Device)
     * @param from ID of the Device that generated the message
     * @param msg Message generated from the Device
     * @return JsonObject
     */
    public static JsonObject update(String from, String msg) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "update")
                .add("from", from)
                .add("message", msg)
                .build();
    }

    /**
     * Generates a message that signals that the a bond has been updated between two Agents
     * (Destined to a Monitor)
     * @param publisher_ID Agent publishing the data
     * @param subscriber_ID Agent subscribed to the publisher and that generated the bond
     * @param subscribingKey Subscribing key
     * @return JsonObject
     */
    public static JsonObject bondUpdate(String publisher_ID, String subscriber_ID, String subscribingKey) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "bond-update")
                .add("publisher_ID", publisher_ID)
                .add("subscriber_ID", subscriber_ID)
                .add("key", subscribingKey)
                .build();
    }

    /**
     * Generates a message that signals that the a bond has been updated between two Agents
     * and that the content of the message is actually destined to the device related to subscriber_ID
     * (Destined to a Monitor)
     * @param publisher_ID Agent publishing the data
     * @param subscriber_ID Agent subscribed to the publisher and that generated the bond
     * @param subscribingKey Subscribing key
     * @return JsonObject
     */
    public static JsonObject msgUpdate(String publisher_ID, String subscriber_ID, String subscribingKey) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "msg-update")
                .add("publisher_ID", publisher_ID)
                .add("subscriber_ID", subscriber_ID)
                .add("key", subscribingKey)
                .build();
    }

    /**
     * Generates a message that signals that the a bond happened between two Agents
     * (Destined to a Monitor)
     * @param publisher_ID Agent publishing the data
     * @param subscriber_ID Agent subscribed to the publisher and that generated the bond
     * @param subscribingKey Subscribing key
     * @return JsonObject
     */
    public static JsonObject bondAdded(String publisher_ID, String subscriber_ID, String subscribingKey) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "bond-added")
                .add("publisher_ID", publisher_ID)
                .add("subscriber_ID", subscriber_ID)
                .add("key", subscribingKey)
                .build();
    }

    /**
     * Generates a message conteining a all the information of the internal Sapere Space.
     * The payload is already a JSONObject.
     * (Destined to a Monitor)
     * @param jsonMap Json-formatted String pre-generated from an HashMap with Gson library.
     * @return JsonObject
     */
    public static JsonObject sapereSpace(String jsonMap) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "lsaspace")
                .add("space", jsonMap)
                .build();
    }

    /**
     * Generates a message that signals that a PublishAgent has been added to the Network Controller Space
     * (Destined to a Monitor)
     * @param publishAgent PublishAgent element
     * @return JsonObject
     */
    public static JsonObject agentAdd(PublishAgent publishAgent) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "publish")
                .add("deviceID", publishAgent.getDeviceID())
                .add("key", publishAgent.getPublishingKey())
                .build();
    }

    /**
     * Generates a message that signals that a SubscribeAgent has been added to the Network Controller Space
     * (Destined to a Monitor)
     * @param subscribeAgent SubscribeAgent element
     * @return JsonObject
     */
    public static JsonObject agentAdd(SubscribeAgent subscribeAgent) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "subscribe")
                .add("deviceID", subscribeAgent.getDeviceID())
                .add("key", subscribeAgent.getSubscribingKey())
                .build();
    }
    
    /**
     * Generates a message that signals that a PublishAgent has been removed from the Network Controller Space
     * (Destined to a Monitor)
     * @param publishAgent PublishAgent element
     * @return JsonObject
     */
    public static JsonObject agentRmv(PublishAgent publishAgent) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "publish-remove")
                .add("deviceID", publishAgent.getDeviceID())
                .add("key", publishAgent.getPublishingKey())
                .build();
    }

    /**
     * Generates a message that signals that a SubscribeAgent has been removed from the Network Controller Space
     * (Destined to a Monitor)
     * @param subscribeAgent SubscribeAgent element
     * @return JsonObject
     */
    public static JsonObject agentRmv(SubscribeAgent subscribeAgent) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "subscribe-remove")
                .add("deviceID", subscribeAgent.getDeviceID())
                .add("key", subscribeAgent.getSubscribingKey())
                .build();
    }

    /**
     * Generates a general error message
     * (Destined to a Monitor)
     * @param message String with the error message
     * @return JsonObject
     */
    public static JsonObject error(String message) {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "error")
                .add("message", message)
                .build();
    }

    /**
     * A Device is already registered with the same ID
     *
     * @return JsonObject
     */
    public static JsonObject errorNODEVICE() {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "error")
                .add("message", "There is no device with the registered with this ID")
                .build();
    }

    /**
     * A Device is already registered with the same ID
     *
     * @return JsonObject
     */
    public static JsonObject errorADDEDALREADY() {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "error")
                .add("type", "added_aldready")
                .add("message", "A Device is already registered with the same ID")
                .build();
    }

    /**
     * The Device is registered to another Session
     *
     * @return JsonObject
     */
    public static JsonObject errorMISMATCH() {
        JsonProvider provider = JsonProvider.provider();
        return provider.createObjectBuilder()
                .add("action", "error")
                .add("type", "session_mismatch")
                .add("message", "The Device is already registered to another Session")
                .build();
    }
}
