/**
 * @module NCAgent
 * @version 1.0
 * @description
 *
 * Implementation of NCAgent_Interface.
 * Every NCAgent_Interface is strictly bonded to a Device.
 * It implements the APIs for managing the Device inside the Network Controller Space.
 *
 * @author Piergiuseppe Mallozzi
 * @date 20/05/15 11:13:00 AM
 */

package network_controller.communication_interface;

import network_controller.handlers.AgentsHandler;
import network_controller.handlers.SapereHandler;
import network_controller.handlers.SessionsHandler;

public class NCAgent implements NCAgent_Interface {

	private String deviceID;

	private SapereHandler sapereHandler;
	private SessionsHandler sessionsHandler;
	private AgentsHandler agentHandler;

	/**
	 * Constructor
	 * @param deviceID ID of the Device the NCAgent is bond to
	 * @param sapereHandler SessionsHandler, needed to execute some callback-functions
	 * @param sessionsHandler SessionsHandler, needed to execute some callback-functions
	 * @param agentHandler AgentsHandler, needed to execute some callback-functions
	 */
	public NCAgent(String deviceID, SapereHandler sapereHandler, SessionsHandler sessionsHandler, AgentsHandler agentHandler){

		this.sapereHandler = sapereHandler;
		this.sessionsHandler = sessionsHandler;
		this.deviceID = deviceID;
		this.agentHandler = agentHandler;
	}

	/**
	 * Every NCAgent is bonded to one and only Device
	 * @return String with the ID of the Device
	 */
	public String getDeviceID() {

		return deviceID;
	}

	/**
     * Creates and Inject into the Space a NCAgent_Interface Publisher
     */
	public void injectPublisher(){

		sapereHandler.injectPublisher(this);
	}

	/**
	 * Update the data being published by a Publisher with the message
	 * @param message Data that needs to be published
	 */
	public void publish(String message) {

		sapereHandler.updateData(this, message);
	}

	/**
     * Subscribes this NCAgent_Interface to ncAgent_interface NCAgent_Interface
     * @param ncAgent_interface NCAgent_Interface to subscribe to
     * @param duplex if true also ncAgent_interface NCAgent_Interface is subscribing to this NCAgent_Interface
     */
    public void subscribe(NCAgent_Interface ncAgent_interface, boolean duplex) {

        sapereHandler.injectSubscriber(this, ncAgent_interface, duplex);
    }

	/**
     * Subscribes this NCAgent_Interface to all other NCAgent_Interfaces present in the Network Controller Space
     * @param duplex if true all the others NCAgent_Interfaces will subscribe to this NCAgent_Interface
     */
	public void subscribeToAll (boolean duplex){

		sapereHandler.subscribeToAll(this, duplex);
	}

	/**
     * Request the removal of the NCAgent_Interface
     */
	public void remove(){

		sapereHandler.remove(this);
	}

	/**
     * Callback - NCAgent_Interfaces has being successfully injected in the Network Controller Space
     */
	public void onInjected(){

		sessionsHandler.setDeviceON(deviceID);
	}

	/**
     * Callback - NCAgent_Interfaces has no more Publisher or Subscriber connected to it
     */
	public void onRemove(){

		sessionsHandler.setDeviceOFF(deviceID);
		agentHandler.onRemove(this);
		sessionsHandler.checkDeviceRemove(deviceID);
	}

	/**
     * Callback - NCAgent_Interfaces has Published the data
     * @param message String containing the message correctly published
	 */
	public void onPublish(String message) {

	}

	/**
     * Callback - NCAgent_Interfaces has received an updated from one of his Subscriptions
     * @param from NCAgent_Interface subscribed to, that originated the message
     * @param message String containing the message
	 */
    public void onSubscribe(NCAgent_Interface from, String message) {

		sessionsHandler.sendToDevice(from.getDeviceID(), deviceID, message);
	}

	/**
	 * Callback - Used to signals errors
	 * @param error String containing the error message
	 */
	public void onError(String error) {

	}

	/**
     * Remove the subscription between this NCAgent_Interface and the ncAgent_interface NCAgent_Interface
     *
     * @param ncAgent_interface NCAgent_Interface subscribed to
     * @param duplex   if true also ncAgent_interface NCAgent_Interface is unSubscribing from this NCAgent_Interface
     */
    public void unSubscribe(NCAgent_Interface ncAgent_interface, boolean duplex) {

        sapereHandler.revokeSubscriber(this, ncAgent_interface);
    }

	/**
     * Callback - NCAgent_Interfaces been successfully unsubscribed from the Device with id = 'from'
     *
	 * @param from deviceID unsubscribed from
	 */
	public void onUnSubscribe(String from) {

	}

}


