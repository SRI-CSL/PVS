/**
 * @module AgentsHandler
 * @version 1.0
 * @description AgentsHandler is a Java Bean that contains all the data structures and the relative functions for managing an NCAgent_Interface. <br>
 * Like the other handlers it persists across the entire duration of an application (ApplicationScoped).
 * @author Piergiuseppe Mallozzi
 * @date 19/05/15 21:00:00 AM
 */

package network_controller.handlers;

import network_controller.communication_interface.NCAgent;
import network_controller.communication_interface.NCAgent_Interface;
import network_controller.json.JsonHelper;
import network_controller.logger.NCLogger;
import network_controller.model.Device;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@ApplicationScoped
public class AgentsHandler {

    private final Map<String, NCAgent_Interface> device_agent = new HashMap<String, NCAgent_Interface>();

    @Inject
    private SessionsHandler sessionsHandler;

    @Inject
    private JsonHelper jsonHelper;

    @Inject
    private SapereHandler sapereHandler;

    @Inject
    private NCLogger ncLogger;
    private ArrayList<NCAgent_Interface> supervisors = new ArrayList<NCAgent_Interface>();
    private ArrayList<String> deviceToBeTurnedON = new ArrayList<String>();
    private ArrayList<String[]> deviceToBeSubscribed = new ArrayList<String[]>();

    /**
     * Switch the device state.
     * @param deviceID ID of the Device
     * @param status Current status of the Device
     */
    public void toggleDevice(String deviceID, String status) {

        if ("ON".equals(status)) {
            turnOFF(deviceID);
        }
        if ("OFF".equals(status)) {
            turnON(deviceID);
        }
    }

    /**
     * Unlock all the TurnON requests of from Devices that were waiting to be added
     */
    public void unlockONRequests() {
        ncLogger.log("  ~~ UNLOCKING-ON.. ~~ " + deviceToBeTurnedON.size());
        ArrayList<String> temp = new ArrayList<String>(deviceToBeTurnedON);
        Iterator<String> it = temp.iterator();
        while (it.hasNext()) {
            String deviceID = it.next();
            turnON(deviceID);
        }

        ncLogger.log("  ~~ UNLOCKING-SUBS.. ~~ " + deviceToBeSubscribed.size());
        ArrayList<String[]> temp1 = new ArrayList<String[]>(deviceToBeSubscribed);
        Iterator<String[]> it1 = temp1.iterator();
        while (it1.hasNext()) {
            String[] values = it1.next();
            addSubscriberQueue(values[0], values[1]);
        }
    }

    private void addSubscriberQueue(String deviceID, String publisherID) {
        String[] values = new String[2];
        values[0] = deviceID;
        values[1] = publisherID;
        if (!deviceToBeSubscribed.contains(values)) {
            deviceToBeSubscribed.add(values);
            ncLogger.log("++ SUBQUEUE -> " + deviceToBeSubscribed.size());
        }
    }

    private void rmvSubscriberQueue(String deviceID, String publisherID) {
        String[] values = new String[2];
        values[0] = deviceID;
        values[1] = publisherID;
        if (deviceToBeSubscribed.contains(values)) {
            deviceToBeSubscribed.remove(values);
            ncLogger.log("-- SUBQUEUE -> " + deviceToBeSubscribed.size());
        }
    }

    public void unSubscribeFrom(String deviceID, String publisherID) {
        NCAgent_Interface subscriber;
        NCAgent_Interface publisher;

        if (device_agent.containsKey(deviceID)) {
            subscriber = device_agent.get(deviceID);
        } else {
            ncLogger.log("!!! Error - " + deviceID + " has no agents");
            return;
        }
        if (device_agent.containsKey(publisherID)) {
            publisher = device_agent.get(publisherID);
        } else {
            ncLogger.log("!!! Error - " + publisherID + " has no agents");
            return;
        }

        subscriber.unSubscribe(publisher, false);
    }

    public void subscribeTo(String deviceID, String publisherID) {
        if (sessionsHandler.isDeviceQueuingToBeAdded(deviceID)) {
            addSubscriberQueue(deviceID, publisherID);
        } else {
            if (sessionsHandler.isDeviceQueuingToBeAdded(publisherID)) {
                addSubscriberQueue(deviceID, publisherID);
            } else {
                Device device = sessionsHandler.getDeviceById(deviceID);

                NCAgent_Interface subscriber;
                NCAgent_Interface publisher;

                if (!device_agent.containsKey(deviceID)) {
                    subscriber = new NCAgent(deviceID, sapereHandler, sessionsHandler, this);
                    device_agent.put(deviceID, subscriber);
                    ncLogger.log("++ NCAgent_Interface -> " + device_agent.size());
                } else {
                    subscriber = device_agent.get(deviceID);
                }
                if (!device_agent.containsKey(publisherID)) {
                    publisher = new NCAgent(publisherID, sapereHandler, sessionsHandler, this);
                    device_agent.put(publisherID, publisher);
                    ncLogger.log("++ NCAgent_Interface -> " + device_agent.size());
                } else {
                    publisher = device_agent.get(publisherID);
                }
                subscriber.subscribe(publisher, false);

                rmvSubscriberQueue(deviceID, publisherID);
            }
        }
    }

    /**
     * Connects the device to Sapere
     * @param deviceID ID of the Device
     */
    public void turnON(String deviceID) {
        if (sessionsHandler.isDeviceQueuingToBeAdded(deviceID)) {
            deviceToBeTurnedON.add(deviceID);
            ncLogger.log("++ ONQUEUE -> " + deviceToBeTurnedON.size());
        } else {
            Device device = sessionsHandler.getDeviceById(deviceID);
            NCAgent_Interface ncAgent_interface;

            if (!device_agent.containsKey(deviceID)) {
                ncAgent_interface = new NCAgent(deviceID, sapereHandler, sessionsHandler, this);
                device_agent.put(deviceID, ncAgent_interface);
                ncLogger.log("++ NCAgent_Interface -> " + device_agent.size());

            } else {
                ncAgent_interface = device_agent.get(deviceID);
            }

            // ***** POLICY 1 **** //
            ncAgent_interface.injectPublisher();
            if (device.getType().equals("Supervisor")) {
                supervisors.add(ncAgent_interface);
                ncLogger.log("++ SUPERVISOR -> " + supervisors.size());
                ncAgent_interface.subscribeToAll(true);
            } else {
                if (!supervisors.isEmpty()) {
                    for (NCAgent_Interface ncAgent_interface1 : supervisors) {
                        ncAgent_interface.subscribe(ncAgent_interface1, true);
                    }
                }
            }
            if (deviceToBeTurnedON.contains(deviceID)) {
                deviceToBeTurnedON.remove(deviceID);
                ncLogger.log("-- ONQUEUE -> " + deviceToBeTurnedON.size());
            }
        }
    }

    /**
     * Disconnects the device from Sapere
     * @param deviceID ID of the Device
     */
    public void turnOFF(String deviceID) {

        if (device_agent.containsKey(deviceID)) {
            NCAgent_Interface ncAgent_interface = device_agent.get(deviceID);
            ncAgent_interface.remove();
        } else {
            ncLogger.log(JsonHelper.error("Device is already in OFF state"));
        }
    }

    /**
     * Callback when Device has all his Agents (PublishAgent and SubscribeAgent) decayed. <br>
     * It remove NCAgent_Interface from internal data structures.
     * @param ncAgent_interface NCAgent_Interface relative to the Device
     */
    public void onRemove(NCAgent_Interface ncAgent_interface) {

        Device device = sessionsHandler.getDeviceById(ncAgent_interface.getDeviceID());
        if (device.getType().equals("Supervisor")) {
            supervisors.remove(ncAgent_interface);
            ncLogger.log("-- SUPERVISOR -> " + supervisors.size());
        }
        device_agent.remove(ncAgent_interface.getDeviceID());
        ncLogger.log("-- NCAgent_Interface -> " + device_agent.size());
    }

    /**
     * Update the data being published by the Device with ID deviceID
     *
     * @param deviceID      ID of the Device
     * @param deviceMessage Data
     */
    public void updateData(String deviceID, String deviceMessage) {

        NCAgent_Interface ncAgent_interface = device_agent.get(deviceID);
        ncAgent_interface.publish(deviceMessage);
    }
}