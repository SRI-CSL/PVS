/**
 * @module EndpointDevice
 * @version 1.0
 * @description
 * EndpointDevice is the websocket endpoint that handles connections to and from Devices (a Supervisor is also a Device). <br>
 * It is a Java Bean persisting across the entire duration of an application (ApplicationScoped).
 * @author Piergiuseppe Mallozzi
 * @date 19/05/15 15:47:00 AM
 */

package network_controller.endpoints;

import network_controller.handlers.AgentsHandler;
import network_controller.handlers.SessionsHandler;
import network_controller.json.JsonHelper;
import network_controller.logger.NCLogger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import java.io.StringReader;

@ApplicationScoped
@ServerEndpoint("/devices") // TODO Change it to /devices
public class EndpointDevice {

    @Inject
    private SessionsHandler sessionsHandler;

    @Inject
    private AgentsHandler agentsHandler;

    @Inject
    private NCLogger ncLogger;

    private boolean firstOpen = false;

    /**
     * Called when a new Device joins the Network Controller
     * @param session Session of the Device
     */
    @OnOpen
    public void open(Session session) {
        if (!firstOpen) {
            firstOpen = true;
        }
        sessionsHandler.addSession(session);
    }

    /**
     * Called when a Device disconnects from the Network Controller
     * @param session Session of the Device
     */
    @OnClose
    public void close(Session session) {
        try {
            if (firstOpen) {
                sessionsHandler.removeSession(session);
            }
        } catch (Exception e) {
            System.out.println("!!! EndpointDevice.close - Exception: \n" + e.getMessage());
            // throw new RuntimeException(e);
        }
    }


    /**
     * It accepts three types of messages:
     * <ul>
     *     <li>"add" for adding a new Device</li>
     *     <li>"update" to send an update message from a Device</li>
     *     <li>"orchestrate" equivalent to "update" but it is used only by the Supervisor</li>
     * </ul>
     * @param message
     * @param session
     */
    @OnMessage
    public void handleMessage(String message, Session session) {
        try (JsonReader reader = Json.createReader(new StringReader(message))) {
            JsonObject jsonMessage = reader.readObject();

            String action;
            if (jsonMessage.containsKey("action")) {
                action = jsonMessage.getString("action");

                /**
                 * Register a new device to the Network Controller Space
                 */
                if ("add".equals(action)) {
                    String deviceID = jsonMessage.getString("deviceID");
                    ncLogger.log("  <<<- ADD " + deviceID);
                    int check = sessionsHandler.checkConsistency(session, deviceID);
                    if (check == -2) { // Device not registered yet
                        sessionsHandler.addRequest(session, jsonMessage);
                    } else {
                        ncLogger.log("!! Attention, a device with id: " + deviceID + " is already added !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorADDEDALREADY());
                    }
                }

                /**
                 * According to the policy implemented and the type of the device,
                 * it connects the device inside the Network Controller Space.
                 * Meaning that it creates the bonding with other devices/supervisors.
                 */
                if ("connect".equals(action)) {
                    String deviceID = jsonMessage.getString("deviceID");
                    ncLogger.log("  <<<- CONNECT " + deviceID);
                    int check = sessionsHandler.checkConsistency(session, deviceID);
                    if (check == 1) { // Device correctly registered
                        agentsHandler.turnON(deviceID);
                    } else if (check == -1) {
                        ncLogger.log("!! Attention, a device with id: " + deviceID + " already belongs to another Session !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorMISMATCH());
                    } else if (check == -2) {
                        ncLogger.log("!! Attention, a device with id: " + deviceID + " is not registered !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorNODEVICE());
                    }

                }

                /**
                 * It disconnect the devices from the Network Controller Space,
                 * It removes all the agents connected to it.
                 */
                if ("disconnect".equals(action)) {
                    String deviceID = jsonMessage.getString("deviceID");
                    ncLogger.log("  <<<- DISCONNECT " + deviceID);
                    int check = sessionsHandler.checkConsistency(session, deviceID);
                    if (check == 1) { // Device correctly registered
                        agentsHandler.turnOFF(deviceID);
                    } else if (check == -1) {
                        ncLogger.log("!! Attention, a device with id: " + deviceID + " already belongs to another Session !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorMISMATCH());
                    } else if (check == -2) {
                        ncLogger.log("!! Attention, a device with id: " + deviceID + " is not registered !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorNODEVICE());
                    }
                }

                /**
                 * Publish a data update into the Network Controller Space
                 */
                if ("publish".equals(action)) {
                    String deviceID = jsonMessage.getString("deviceID");
                    ncLogger.log("  <<<- PUBLISH " + deviceID);
                    int check = sessionsHandler.checkConsistency(session, deviceID);
                    if (check == 1) { // Device correctly registered
                        String deviceMessage;

                        try { // normal message

                            deviceMessage = jsonMessage.getString("message");
                        } catch (Exception e) { // json (Supervisor message)

                            deviceMessage = jsonMessage.get("message").toString();
                        }
                        agentsHandler.updateData(deviceID, deviceMessage);
                    } else if (check == -1) {
                        ncLogger.log("!! Attention, a device with id: " + deviceID + " already belongs to another Session !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorMISMATCH());
                    } else if (check == -2) {
                        ncLogger.log("!! Attention, a device with id: " + deviceID + " is not registered !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorNODEVICE());
                    }
                }

                /**
                 * <Experimental APIs>
                 */

                if ("subscribe".equals(action)) {
                    String deviceID = jsonMessage.getString("deviceID");
                    String publisherID = jsonMessage.getString("publisherID");
                    ncLogger.log("  <<<- SUBSCRIBE " + deviceID + " TO " + publisherID);
                    int check_1 = sessionsHandler.checkConsistency(session, deviceID);
                    int check_2 = sessionsHandler.checkConsistency(session, publisherID);
                    if (check_1 == 1 && check_2 == 1) { // Devices correctly registered
                        agentsHandler.subscribeTo(deviceID, publisherID);
                    } else if (check_1 == -1 || check_2 == -1) {
                        ncLogger.log("!! Attention, one or more devices mismatch their Sessions !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorMISMATCH());
                    } else if (check_1 == -2 || check_2 == -2) {
                        ncLogger.log("!! Attention, one or more devices are not registered not registered !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorNODEVICE());
                    }
                }

                if ("un-subscribe".equals(action)) {
                    String deviceID = jsonMessage.getString("deviceID");
                    String publisherID = jsonMessage.getString("publisherID");
                    ncLogger.log("  <<<- UNSUBSCRIBE " + deviceID + " FROM " + publisherID);
                    int check_1 = sessionsHandler.checkConsistency(session, deviceID);
                    int check_2 = sessionsHandler.checkConsistency(session, publisherID);
                    if (check_1 == 1 && check_2 == 1) { // Devices correctly registered
                        agentsHandler.unSubscribeFrom(deviceID, publisherID);
                    } else if (check_1 == -1 || check_2 == -1) {
                        ncLogger.log("!! Attention, one or more devices mismatch their Sessions !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorMISMATCH());
                    } else if (check_1 == -2 || check_2 == -2) {
                        ncLogger.log("!! Attention, one or more devices are not registered not registered !!");
                        sessionsHandler.sendToSession(session, JsonHelper.errorNODEVICE());
                    }
                }

                /**
                 * </Experimental APIs>
                 */


            } else {

            }

        }
    }
}

