/**
 * @module SapereSpace
 * @version 1.0
 * @description
 *
 * Once initialized it receives notification on any changes in the internal Sapere Space
 *
 * @author Piergiuseppe Mallozzi
 * @date 20/05/15 1:13:00 PM
 */

package network_controller.sapere;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import eu.sapere.middleware.lsa.Lsa;
import eu.sapere.middleware.node.lsaspace.IVisualSpaceHandler;
import eu.sapere.middleware.node.lsaspace.SpaceView;
import network_controller.json.JsonHelper;
import network_controller.logger.NCLogger;

import java.util.HashMap;

//@ApplicationScoped
public class SapereSpace implements IVisualSpaceHandler {

    private NCLogger ncLogger;

    public SapereSpace(NCLogger ncLogger){
        this.ncLogger = ncLogger;
        SpaceView.setSpaceUpdateHandler(this);
    }

    /**
     * Executed every time something changes in the internal Sapere Space
     * The entire HashMap of the Sapere Space is converted into a Json object and sent to the NCLogger
     * @param newVisualSpace HashMap containing the current picture of the Sapere Space
     */
    @Override
    public void onSpaceUpdate(final HashMap<String, Lsa> newVisualSpace){

        Gson gson = new GsonBuilder().create();
        String jsonMap = gson.toJson(newVisualSpace);
        ncLogger.log(JsonHelper.sapereSpace(jsonMap));

    }
}
