/**
 * @module NCAgent_Interface
 * @version 1.0
 * @description
 *
 * Interface NCAgent_Interface, it defines the API used for managing the Device inside the Network Controller Space
 * Every NCAgent_Interface is strictly bonded to a Device.
 *
 * @author Piergiuseppe Mallozzi
 * @date 20/05/15 11:13:00 AM
 */

package network_controller.communication_interface;

public interface NCAgent_Interface {

	/**
	 * Every NCAgent is bonded to one and only Device
	 * @return String with the ID of the Device
	 */
	String getDeviceID();

	/**
	 * Creates and Inject into the Network Controller Space a NCAgent_Interface Publisher
	 */
	void injectPublisher();

	/**
	 * Update the data being published by a Publisher with the message
	 * @param message Data that needs to be published
	 */
	void publish(String message);

	/**
	 * Subscribes this NCAgent_Interface to ncAgent_interface NCAgent_Interface
	 * @param ncAgent_interface NCAgent_Interface to subscribe to
	 * @param duplex if true also ncAgent_interface NCAgent_Interface is subscribing to this NCAgent_Interface
	 */
	void subscribe(NCAgent_Interface ncAgent_interface, boolean duplex);

	/**
	 * Subscribes this NCAgent_Interface to all other NCAgent_Interfaces present in the Network Controller Space
	 * @param duplex if true all the others NCAgent_Interfaces will subscribe to this NCAgent_Interface
	 */
	void subscribeToAll (boolean duplex);

	/**
	 * Remove the subscription between this NCAgent_Interface and the ncAgent_interface NCAgent_Interface
	 * @param ncAgent_interface NCAgent_Interface subscribed to
	 * @param duplex if true also ncAgent_interface NCAgent_Interface is unSubscribing from this NCAgent_Interface
	 */
	void unSubscribe(NCAgent_Interface ncAgent_interface, boolean duplex);

	/**
	 * Request the removal of the NCAgent_Interface
	 */
	void remove();

	/**
	 * Callback - NCAgent_Interfaces has being successfully injected in the Network Controller Space
	 */
	void onInjected();

	/**
	 * Callback - NCAgent_Interfaces has no more Publisher or Subscriber connected to it
	 */
	void onRemove();

	/**
	 * Callback - NCAgent_Interfaces has Published the data
	 * @param message String containing the message correctly published
	 */
	void onPublish(String message);

	/**
	 * Callback - NCAgent_Interfaces has received an updated from one of his Subscriptions
	 * @param from NCAgent_Interface subscribed to, that originated the message
	 * @param message String containing the message
	 */
	void onSubscribe(NCAgent_Interface from, String message);

	/**
	 * Callback - NCAgent_Interfaces been successfully unsubscribed from the Device with id = 'from'
	 *
	 * @param from deviceID unsubscribed from
	 */
	void onUnSubscribe(String from);

	/**
	 * Callback - Used to signals errors
	 * @param error String containing the error message
	 */
	void onError(String error);


}


