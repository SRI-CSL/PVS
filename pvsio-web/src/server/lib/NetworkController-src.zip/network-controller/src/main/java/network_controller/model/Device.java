/**
 * @module Device
 * @version 1.0
 * @description
 * It defines the Device Object.
 * A Device can be in two states:
 * <ul>
 *     <li>"ON": Meaning that is enable to transmit-receives data from other Devices, hence is not registered at all in the Sapere Space</li>
 *     <li>"OFF": Meaning that is not registered in Sapere, hence it doesn't have any Publish-Subscribe Agent <br>
 *         Although the device is registered to the Network Controller and it is visible to the Monitor</li>
 * </ul>
 * @author Piergiuseppe Mallozzi
 * @date 19/05/15 18:47:00 AM
 */

package network_controller.model;

public class Device {

    private String deviceID;
    private String status;
    private String type;
    private String description;

    /**
     * @param deviceID ID of the Device
     * @param type Type of the Device. Special type: "Supervisor"
     * @param description Description of the Device
     */
    public Device(String deviceID, String type, String description) {
        this.deviceID = deviceID;
        this.type = type;
        this.description = description;
        this.status = "OFF";
    }

    public String getDeviceID() {
        return deviceID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public boolean isSupervisor(){
        return type.equals("Supervisor");
    }

    public boolean isConnected() {
        return status.equals("ON");
    }


}