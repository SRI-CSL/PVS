/**
 * @module SapereHandler
 * @version 1.0
 * @description
 * SapereHandler is a Java Bean that contains all the data structures and the relative functions
 * for managing an Sapere elements like PublishAgent, EventGenerator and SubscribeAgent. <br>
 * It is like an API for Sapere Middleware that saves information between Sapere data structures and NCAgent_Interfaces. <br>
 * Like the other handlers it persists across the entire duration of an application (ApplicationScoped).
 * @author Piergiuseppe Mallozzi
 * @date 19/05/15 21:00:00 AM
 */

package network_controller.handlers;

import eu.sapere.middleware.lsa.autoupdate.EventGenerator;
import network_controller.communication_interface.NCAgent_Interface;
import network_controller.json.JsonHelper;
import network_controller.logger.NCLogger;
import network_controller.sapere.PublishAgent;
import network_controller.sapere.SubscribeAgent;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.websocket.Session;
import java.util.*;

@ApplicationScoped
public class SapereHandler {

    private final Map<NCAgent_Interface, PublishAgent> agent_pubagent = new HashMap<NCAgent_Interface, PublishAgent>();
    private final Map<NCAgent_Interface, List<SubscribeAgent>> agent_listsubagents = new HashMap<NCAgent_Interface, List<SubscribeAgent>>();
    @Inject
    private SessionsHandler sessionsHandler;
    @Inject
    private JsonHelper jsonHelper;
    @Inject
    private NCLogger ncLogger;

    /**
     * Initialize a Publisher Agent and Inject it into the Sapere Space
     * @param ncAgent_interface Network Controller Agent containing the PublishAgent
     */
    public void injectPublisher(NCAgent_Interface ncAgent_interface) {

        EventGenerator dataEvent = new EventGenerator() {};
        PublishAgent publishAgent = new PublishAgent(ncAgent_interface, dataEvent, this, ncLogger);
        agent_pubagent.put(ncAgent_interface, publishAgent);
        ncLogger.log("    ++ PUBMAP -> " + agent_pubagent.size());
        publishAgent.setInitialLSA();
        ncAgent_interface.onInjected();
    }

    /**
     * Initialize a Subscriber Agent and link it to the NCAgent_Interface
     * @param ncAgent_interface Network Controller Agent containing the SubscribeAgent
     * @param publisherID Network Controller Agent to subscribe to (containing the PublishAgent)
     * @param duplex Boolean value, if true it also subscribe the publisherID to the ncAgent_interface
     */
    public void injectSubscriber(NCAgent_Interface ncAgent_interface, NCAgent_Interface publisherID, boolean duplex) {

        subscribeTo(ncAgent_interface, publisherID);
        if(duplex){
            subscribeTo(publisherID, ncAgent_interface);
        }

        ncAgent_interface.onInjected();
    }

    /**
     * Subscribe ncAgent_interface to publisherID
     * @param ncAgent_interface Network Controller Agent containing the SubscribeAgent
     * @param publisherID Network Controller Agent to subscribe to (containing the PublishAgent)
     */
    private void subscribeTo(NCAgent_Interface ncAgent_interface, NCAgent_Interface publisherID) {
        if (!agent_listsubagents.containsKey(ncAgent_interface)) {
            List<SubscribeAgent> subscribeAgents = new ArrayList<SubscribeAgent>();
            agent_listsubagents.put(ncAgent_interface, subscribeAgents);
            ncLogger.log("    ++ SUBMAP -> " + agent_listsubagents.size());
        }
        SubscribeAgent subscribeAgent = new SubscribeAgent(ncAgent_interface, publisherID, this, ncLogger);
        List<SubscribeAgent> subscribeAgents = agent_listsubagents.get(ncAgent_interface);
        subscribeAgents.add(subscribeAgent);
        ncLogger.log("    ++ SUBMAP->SUBLIST -> " + subscribeAgents.size());
        subscribeAgent.setInitialLSA();
    }

    /**
     * Subscribe ncAgent_interface to all NCAgent_Interfaces containing a PublishAgent
     * @param ncAgent_interface NCAgent_Interface that wants to subscribe
     * @param duplex Boolean value, if true all the NCAgent_Interfaces that that ncAgent_interface is subscribing to will also subscribe to ncAgent_interface
     */
    public void subscribeToAll(NCAgent_Interface ncAgent_interface, boolean duplex) {

        for (Map.Entry<NCAgent_Interface, PublishAgent> entryPublishers : agent_pubagent.entrySet()) {
            if (entryPublishers.getKey() != ncAgent_interface) {
                injectSubscriber(ncAgent_interface, entryPublishers.getKey(), duplex);
            }
        }
    }

    /**
     * Send a Decay command to the PublishAgent connected to the NCAgent_Interface ncAgent_interface. <br>
     * This command will be propagated inside Sapere and when the PublishAgent will be completely removed then
     * the callback function onPublishDecayed is executed.
     * @param ncAgent_interface NCAgent_Interface containing the PublishAgent
     */
    public void revokePublisher(NCAgent_Interface ncAgent_interface) {

        PublishAgent publishAgent = agent_pubagent.get(ncAgent_interface);
        publishAgent.decay();
        ncLogger.log("        ** AddDecay -> " + publishAgent.getAgentName());
    }

    /**
     * Send a Decay command to all the SubscribeAgents connected to the NCAgent_Interface ncAgent_interface. <br>
     * This command will be propagated inside Sapere and when each SubscribeAgent will be completely removed then
     * the callback function onSubscribeDecayed is executed.
     * @param ncAgent_interface NCAgent_Interface containing the PublishAgent
     */
    public void revokeAllSubscribers(NCAgent_Interface ncAgent_interface) {

        if (agent_listsubagents.containsKey(ncAgent_interface)) {

            List<SubscribeAgent> subscribeAgents = agent_listsubagents.get(ncAgent_interface);

            for (Iterator<SubscribeAgent> i = subscribeAgents.iterator(); i.hasNext(); ) {
                SubscribeAgent subscribeAgent = i.next();
                subscribeAgent.decay();
                ncLogger.log("        ** AddDecay -> " + subscribeAgent.getAgentName());
            }
        }
    }

    public void revokeSubscriber(NCAgent_Interface ncAgent_interface, NCAgent_Interface publisherID) {
        if (agent_listsubagents.containsKey(ncAgent_interface)) {

            List<SubscribeAgent> subscribeAgents = agent_listsubagents.get(ncAgent_interface);

            for (Iterator<SubscribeAgent> i = subscribeAgents.iterator(); i.hasNext(); ) {
                SubscribeAgent subscribeAgent = i.next();
                if (subscribeAgent.getPublisherID().equals(publisherID.getDeviceID())) {
                    subscribeAgent.decay();
                    ncLogger.log("        ** AddDecay -> " + subscribeAgent.getAgentName());
                }
            }
        }
    }

    /**
     * Send a Decay command to all the SubscribeAgents subscribed to the PublishAgent related to the NCAgent_Interface ncAgent_interface
     * This command will be propagated inside Sapere and when each SubscribeAgent will be completely removed then
     * the callback function onSubscribeDecayed is executed.
     * @param ncAgent_interface NCAgent_Interface containing the PublishAgent
     */
    public void revokeAllSubscriberdTo(NCAgent_Interface ncAgent_interface) {

        PublishAgent publishAgent = agent_pubagent.get(ncAgent_interface);

        for (Map.Entry<NCAgent_Interface, List<SubscribeAgent>> entry : agent_listsubagents.entrySet()) {
            List<SubscribeAgent> subscribeList = entry.getValue();
            for (Iterator<SubscribeAgent> i = subscribeList.iterator(); i.hasNext(); ) {
                SubscribeAgent subAgent = i.next();
                if (subAgent.getSubscribingKey().equals(publishAgent.getPublishingKey())) {
                    subAgent.decay();
                    ncLogger.log("        ** AddDecay -> " + subAgent.getAgentName());
                }
            }
        }

    }

    /**
     * Revoke all the Agents (SubscribeAgents and PublishAgent) connected to the NCAgent_Interface ncAgent_interface
     * When all the Agents will be completely decayed then the the callback function onRemove will be
     * executed and the NCAgent_Interface ncAgent_interface will be removed from the data structures.
     * @param ncAgent_interface NCAgent_Interface that
     */
    public void remove(NCAgent_Interface ncAgent_interface) {
        revokeAllSubscriberdTo(ncAgent_interface);
        revokeAllSubscribers(ncAgent_interface);
        revokePublisher(ncAgent_interface);
    }

    /**
     * Update the data that the PublishAgent related the the NCAgent_Interface ncAgent_interface is publishing
     * @param ncAgent_interface NCAgent_Interface containing the PublishAgent
     * @param deviceMessage String containing the data that need to be published
     */
    public void updateData(NCAgent_Interface ncAgent_interface, String deviceMessage) {

        PublishAgent publishAgent = agent_pubagent.get(ncAgent_interface);
        publishAgent.publishData(deviceMessage);
    }

    /**
     * Callback function, executed when the PublishAgent publishAgent has been completely removed from Sapere
     * If the NCAgent_Interface ncAgent_interface containing the PublishAgent that decayed has no other Agents,
     * then the onRemove function is executed.
     * @param publishAgent PublishAgent removed
     * @param ncAgent_interface NCAgent_Interface related to the PublishAgent
     */
    public void onPublishDecayed(PublishAgent publishAgent, NCAgent_Interface ncAgent_interface) {

        ncLogger.log("        ^^ Decayed -> " + publishAgent.getAgentName());
        removeAgentFromDataStructures(publishAgent);

        // If it has no more agents
        if (!ncAgent_interfaceHasAgents(publishAgent.getINcAgent())) {
            ncAgent_interface.onRemove();
        }
    }

    /**
     * Callback function, executed when the SubscribeAgent subscribeAgent has been completely removed from Sapere
     * If the NCAgent_Interface ncAgent_interface containing the SubscribeAgent that decayed has no other Agents,
     * then the onRemove function is executed.
     * @param subscribeAgent SubscribeAgent removed
     * @param ncAgent_interface NCAgent_Interface related to the SubscribeAgent
     */
    public void onSubscribeDecayed(SubscribeAgent subscribeAgent, NCAgent_Interface ncAgent_interface) {

        ncLogger.log("        ^^ Decayed -> " + subscribeAgent.getAgentName());
        removeAgentFromDataStructures(subscribeAgent);
        sessionsHandler.sendToAllMonitors(JsonHelper.agentRmv(subscribeAgent));
        ncAgent_interface.onUnSubscribe(subscribeAgent.getPublisherID());

        // If it has no more agents
        if (!ncAgent_interfaceHasAgents(subscribeAgent.getINcAgent())) {
            ncAgent_interface.onRemove();
        }
    }

    /**
     * Completely remove the SubscribeAgent subscribeAgent from internal data structures.
     * This function is executed after the Agent has successfully decayed from Sapere.
     * @param subscribeAgent SubscribeAgent that has to be removed.
     */
    private void removeAgentFromDataStructures(SubscribeAgent subscribeAgent) {

        Iterator<Map.Entry<NCAgent_Interface, List<SubscribeAgent>>> it = agent_listsubagents.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<NCAgent_Interface, List<SubscribeAgent>> entry = it.next();
            List<SubscribeAgent> subscribeList = entry.getValue();
            Iterator<SubscribeAgent> i = subscribeList.iterator();
            while (i.hasNext()) {
                SubscribeAgent subAgent = i.next();
                if (subAgent.getAgentName() == subscribeAgent.getAgentName()) {
                    i.remove();
                    ncLogger.log("    -- SUBMAP->SUBLIST -> " + subscribeList.size());
                }
            }
            if (subscribeList.size() == 0) {
                it.remove();
                ncLogger.log("    -- SUBMAP -> " + agent_listsubagents.size());
            }
        }
        ncLogger.log(JsonHelper.agentRmv(subscribeAgent));
    }

    /**
     * Completely remove the PublishAgent subscribeAgent from internal data structures.
     * This function is executed after the Agent has successfully decayed from Sapere.
     * @param publishAgent PublishAgent that has to be removed.
     */
    private void removeAgentFromDataStructures(PublishAgent publishAgent) {

        agent_pubagent.remove(publishAgent.getINcAgent());
        ncLogger.log("    -- PUBMAP -> " + agent_pubagent.size());
        ncLogger.log(JsonHelper.agentRmv(publishAgent));
    }

    /**
     * Utility function that check if the NCAgent_Interface ncAgent_interface has any Agent connected to it
     * @param ncAgent_interface NCAgent_Interface to be checked
     * @return true if the NCAgent_Interface ncAgent_interface has at least one Agent (SubscribeAgent or PublishAgent) connected to it.
     */
    private boolean ncAgent_interfaceHasAgents(NCAgent_Interface ncAgent_interface) {

        boolean res = false;
        if (agent_pubagent.containsKey(ncAgent_interface)) {
            res = true;
        }
        if (agent_listsubagents.containsKey(ncAgent_interface)) {
            res = true;
        }
        return res;
    }

    /**
     * Function that sends informations about all the Agents (SubscribeAgents and PublishAgents)
     * to the Monitor specified as parameter.
     * In this way the Monitors can have a clear pictures of all the Agents present in the Network Controller.
     * This function is usually called when a Monitor joins the Network Controller Space.
     * @param session Monitor session that wants to receive the state of the Agents
     */
    public void sendAllAgentsToMonitors(Session session) {

        for (Map.Entry<NCAgent_Interface, PublishAgent> entryPublishers : agent_pubagent.entrySet()) {
            PublishAgent publishAgent = entryPublishers.getValue();
            sessionsHandler.sendToMonitor(JsonHelper.agentAdd(publishAgent), session);
        }
        for (Map.Entry<NCAgent_Interface, List<SubscribeAgent>> entrySubscribers : agent_listsubagents.entrySet()) {
            List<SubscribeAgent> subscribeAgentsList = entrySubscribers.getValue();
            for (SubscribeAgent subscribeAgent : subscribeAgentsList) {
                sessionsHandler.sendToMonitor(JsonHelper.agentAdd(subscribeAgent), session);
            }
        }
    }

}