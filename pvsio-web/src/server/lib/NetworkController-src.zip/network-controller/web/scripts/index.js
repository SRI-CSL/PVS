/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50, browser:true*/
/*global require*/

require.config({
    baseUrl: './scripts/js-modules',
    paths: {
        NCMonitorCore: 'NCMonitorCore',
        NCMonitorRendering: 'NCMonitorRendering'
    }
});
/**
 * Loading the module PVSioWebClient.
 */
require([
    'NCMonitorCore', 'NCMonitorRendering'
], function (NCMonitorCore, NCMonitorRendering) {

    /**
     * NCMonitorCore preferences
     */
    var error_mode = false;
    var debugging_mode_backend = false;
    var debugging_mode_frontend = false;
    var extended_mode = true;

    function errorMessage(event) {
        if (error_mode) {
            console.log("!!! " + event.message);
        }
    }

    function notifyMessage(event) {
        if (debugging_mode_frontend) {
            console.log(">>> " + event.message);
        }
    }

    function debugMessage(event) {
        if (debugging_mode_backend) {
            console.log(">!> " + event.message);
        }
    }


    function renderAction(event) {
        var data = event.data;
        ncMonitorRendering.renderAction(data);

    }


    var urlMonitor = window.location.origin.split(":").slice(0, 2).join(":") + ":8080/NetworkController/monitor";
    urlMonitor = urlMonitor.replace("http://", "ws://");

    var ncMonitorCore = new NCMonitorCore({
        extended: extended_mode,
        debugging: debugging_mode_backend,
        url: urlMonitor
    });

    var ncMonitorRendering = new NCMonitorRendering({extended: extended_mode, ncMonitorCore: ncMonitorCore});

    ncMonitorCore.addListener("error", errorMessage);
    ncMonitorCore.addListener("notify", notifyMessage);
    ncMonitorCore.addListener("debug_backend", debugMessage);
    ncMonitorCore.addListener("action", renderAction);

    ncMonitorRendering.addListener("error", errorMessage);
    ncMonitorRendering.addListener("notify", notifyMessage);


    ncMonitorCore.start();

    $(window).resize(function () {
        ncMonitorRendering.printConnectionsSapere();
    });

    $(document).ready(function () {
        $('.tooltip').tooltipster();
    });

    $('#toggle_front_debugging').click(function () {
        debugging_mode_frontend = !debugging_mode_frontend;
    });

    $('#toggle_back_debugging').click(function () {
        if (debugging_mode_backend) {
            debugging_mode_backend = false;
            ncMonitorCore.deactivateDebug();
        }
        else {
            debugging_mode_backend = true;
            ncMonitorCore.activateDebug();
        }
    });

    $('#toggle_errors').click(function () {
        error_mode = !error_mode;
    });


});