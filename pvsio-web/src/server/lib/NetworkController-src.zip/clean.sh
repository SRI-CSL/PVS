#!/bin/bash
echo "Removing PVSio-web Network Controller compiled files..."
ant clean -buildfile sapere-javaee.xml &> clean.log
rm -rf out
rm -rf network-controller/bin
rm -rf sapere-core/bin
echo "Done!"
